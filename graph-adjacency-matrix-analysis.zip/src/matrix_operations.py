
import numpy as np

def create_adjacency_matrix():
    """Return the fixed 6x6 adjacency matrix used in the project."""
    A = np.array([
        [0, 1, 1, 0, 0, 0],  # Vertex 1
        [0, 0, 1, 0, 1, 0],  # Vertex 2
        [0, 0, 0, 1, 0, 0],  # Vertex 3
        [0, 0, 0, 0, 1, 0],  # Vertex 4
        [0, 0, 0, 0, 0, 1],  # Vertex 5
        [0, 0, 0, 0, 0, 0]   # Vertex 6
    ], dtype=float)
    return A

def determinant(matrix: np.ndarray) -> float:
    """Compute the determinant of a square matrix."""
    return float(np.linalg.det(matrix))
